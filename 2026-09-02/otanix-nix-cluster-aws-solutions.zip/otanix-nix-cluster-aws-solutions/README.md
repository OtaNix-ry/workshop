# Kubernetes Meets NixOS

Workshop scaffold for configuring SSH-reachable NixOS hosts with Colmena, forming a k3s cluster, rendering Kubernetes manifests with Nixidy, and publishing them as an OCI artifact to be applied by Flux.

## Structure

This flake uses [`flake-parts`](https://flake.parts/) for its structure, consisting of these modules:

- [`flake-modules/dev.nix`](flake-modules/dev.nix) defines development-related options, namely `formatter` and `devShells`
- [`flake-modules/hosts.nix`](flake-modules/hosts.nix) defines options for defining hosts more concisely
- [`flake-modules/kubernetes.nix`](flake-modules/kubernetes.nix) defines a simple adapter to build OCI artifacts from Nixidy definitions
- [`flake-modules/vms.nix`](flake-modules/vms.nix) defines the optional local VM scaffolding, which spawns NixOS hosts via QEMU

## Sections

### Provisioning NixOS hosts

For the complete highly available setup in this workshop, you'll need three NixOS machines accessible via SSH. The initial exercises can be completed with one machine. If you wish, you may spawn the machines as QEMU VMs on your local machine (see the [instructions](docs/local-vms.md)).

Before proceeding to the next section, you should be able to open an SSH connection to all of your hosts, which should be running NixOS:

```
ssh root@<host>
...
[root@magpie:~]# grep -E '^(PRETTY_NAME)=' /etc/os-release
PRETTY_NAME="NixOS 26.11 (Zokor)"

[root@magpie:~]# nix run nixpkgs#hello
Hello, world!
```

### Managing remote hosts with Colmena

While there are multiple decent approaches for managing remote NixOS hosts, we'll use [Colmena](https://github.com/nix-community/colmena), as it's a relatively simple option.

A typical flake using Colmena might look like this:

```nix
{
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    colmena.url = "github:zhaofengli/colmena";
  };
  outputs = { nixpkgs, colmena, ... }: {
    colmenaHive = colmena.lib.makeHive {
      meta = {
        nixpkgs = import nixpkgs {
          system = "x86_64-linux";
          overlays = [];
        };
      };
      host-a = {
        deployment = {
          targetHost = "somehost.tld";
          targetPort = 1234;
          targetUser = "root";
        };
        boot.isContainer = true;
        time.timeZone = "America/Los_Angeles";
      };
    };
  };
}
```

The `colmenaHive` output is a similar pattern to `nixosConfigurations`, but the entire "hive" shares the `meta` portion by default. Within each host, there's also the extra `deployment` field, which isn't included in the actual NixOS closure, but rather is used by the `colmena` CLI to connect to the target host.

For reference, the equivalent NixOS configuration would look something like this, excluding the `pkgs` instance:

```nix
  nixosConfigurations = {
    host-a = nixpkgs.lib.nixosSystem {
      modules = [
        {
          boot.isContainer = true;
          time.timeZone = "America/Los_Angeles";
        }
      ];
    };
  };
```

Our scaffolding in this repository uses [`flake-modules/hosts.nix`](flake-modules/hosts.nix) to generate most of the boilerplate for Colmena, and to allow reusing the same config for the local VMs. Here's the equivalent host entry for [`hosts/default.nix`](hosts/default.nix):

```nix
host-a = {
    system = "x86_64-linux";
    targetHost = "somehost.tld";
    targetPort = 1234;
    # targetUser is always "root" in this workshop

    modules = [
      {
        boot.isContainer = true;
        time.timeZone = "America/Los_Angeles";
      }
    ];
  };
```

Applying the configuration for the entire Colmena Hive is as simple as running `colmena apply`. Targeting specific hosts is possible by adding `--on <host>`, e.g. `--on host-a`.

#### Tasks

To get started with Colmena, proceed with the following:

1. Define all your hosts in [`hosts/default.nix`](hosts/default.nix)
2. Add your SSH public key to [`hosts/modules/deployment-access.nix`](hosts/modules/deployment-access.nix)
3. Get the `colmena` CLI in your shell
   - You can, for example, use the dev shell defined in [`flake-modules/dev.nix`](flake-modules/dev.nix) with `nix develop`.

**Ensure your hosts have your SSH public key configured!** Otherwise you may lock yourself out!

Then, you should be ready to run `colmena apply`; you can use `--on <host>` to test one host first.
For validation, you can try adding some package in [`hosts/modules/common.nix`](hosts/modules/common.nix), applying via `colmena apply`, and testing it out via SSH.

**Note:** You may need to reboot the nodes for the hostnames to apply!

### Deploying Kubernetes on NixOS via k3s

Next, let's start configuring our NixOS hosts to run Kubernetes; we'll do this using [K3s](https://k3s.io/), which is a lightweight Kubernetes distribution. It bundles all the core components into a single binary, making it simple to deploy, and conveniently it already has [NixOS options](https://github.com/NixOS/nixpkgs/blob/master/pkgs/applications/networking/cluster/k3s/README.md) in `nixpkgs`.

#### Tasks

To start with a simple deployment, configure K3s for a _single_ node first. See the examples in the [upstream documentation](https://github.com/NixOS/nixpkgs/blob/master/pkgs/applications/networking/cluster/k3s/docs/USAGE.md#single-node). You can create a new file in the `hosts/modules` directory for this, then include it in one node's module list.

If everything goes correctly, you shouldn't get any errors when deploying. If you SSH onto the host, you should be able to run the following:

```
[root@magpie:~]# kubectl get nodes
NAME     STATUS   ROLES           AGE   VERSION
magpie   Ready    control-plane   93s   v1.35.7+k3s1
```

A single-node Kubernetes cluster is enough for e.g. testing how the ecosystem works. For example, you can see the pods (groups of containers) the node is running with the following:

```
[root@magpie:~]# kubectl get pods --all-namespaces
NAMESPACE     NAME                                      READY   STATUS      RESTARTS   AGE
kube-system   coredns-c5fdd76cf-pkmvd                   1/1     Running     0          2m54s
kube-system   helm-install-traefik-crd-p478q            0/1     Completed   0          2m50s
kube-system   helm-install-traefik-rlgmx                0/1     Completed   2          2m50s
kube-system   local-path-provisioner-5d9d9885bc-g55nx   1/1     Running     0          2m54s
kube-system   metrics-server-7f4b6d9bd7-m28c6           1/1     Running     0          2m54s
kube-system   svclb-traefik-6699797f-98fk7              2/2     Running     0          2m25s
kube-system   traefik-697644c477-qpsln                  1/1     Running     0          2m26s
```

### Deploying a multi-node cluster

To actually pool our nodes into a single cluster, we'll have to do a bit more configuration.

In Kubernetes, there are two kinds of nodes: _control-plane_ and _worker_; both types run the core components that allow running workloads, but only the former run the components that maintain the cluster itself. In K3s, these map to the roles `server` and `agent`. Additionally, typically control plane nodes don't run generic workloads, but that is configurable.

The two important control plane components for this workshop are [`etcd`](https://kubernetes.io/docs/concepts/architecture/#etcd), a distributed key-value store where the cluster state is stored, and [`kube-apiserver`](https://kubernetes.io/docs/concepts/architecture/#kube-apiserver), which exposes the Kubernetes HTTP API.

For our small cluster, we could keep one node as a control plane and join the others as normal workers, but in that configuration the whole cluster depends on the single control plane node being healthy; instead, we can deploy three control plane nodes, to maintain the cluster even if a single node drops (quorum requires _at least two_ nodes to be healthy, hence three nodes).

#### Tasks

A multi-node cluster is typically bootstrapped by a _single_ node first, and the rest will join afterwards; this is done using a shared secret token, which authenticates the joining nodes. This token is slightly problematic in the Nix ecosystem, as the full system configuration is stored in the world-readable Nix store; however, there are neat ways to circumvent this. For now, you can ignore this and proceed with a throwaway token; we'll tackle this in the next section. Alternatively, you can skip to the next section to set up a secure way to deploy the token, then return back here.

To finish the multi-node config, you can again refer to the [upstream documentation](https://github.com/NixOS/nixpkgs/blob/master/pkgs/applications/networking/cluster/k3s/docs/USAGE.md#multi-node). **Remember: only a single node should have `clusterInit` set, and no `serverAddr`**; you may either split the logic into separate modules, or make use of the `host.role` field.

If the hosts have multiple network interfaces, you should specify which one K3s uses:

```nix
services.k3s.extraFlags = [
  "--flannel-iface=cluster0"
  "--node-ip=${host.clusterAddress}"
];
```

If the cluster is formed successfully, you should see all nodes via `kubectl`:

```
[root@crow:~]# kubectl get nodes
NAME     STATUS   ROLES                AGE    VERSION
crow     Ready    control-plane,etcd   84s    v1.35.7+k3s1
magpie   Ready    control-plane,etcd   101s   v1.35.7+k3s1
raven    Ready    control-plane,etcd   71s    v1.35.7+k3s1
```

### Handling secrets with agenix

As mentioned before, the K3s service depends on a shared secret token, which allows machines to join the cluster; if this token is leaked, it would allow a malicious machine to join the cluster and gain access to the `etcd` database, reading e.g. cluster secrets. Normally this wouldn't be a major issue, but this is where Nix bites us: configuring the token as part of the system configuration includes it in the closure, which is stored in the nix store, which is, by design, world-readable. Even worse, if you use a caching service, the closure may end up on a remote host.

However, there are various methods of deploying these kinds of secrets with Nix, usually using some form outside of the typical closure. Two popular options are [`sops-nix`](https://github.com/mic92/sops-nix) and [`agenix`](https://github.com/ryantm/agenix), of which we'll be using the latter. `agenix` specifically uses the [`age`](https://github.com/FiloSottile/age) encryption tool instead of GPG (though other tools are beginning to support it as well), and secrets are encrypted against the target's _SSH host public key_.

#### Tasks

Refer to the [upstream configuration](https://github.com/ryantm/agenix#tutorial) for instructions how to wire in `agenix`. Our [scaffolding](flake-modules/hosts.nix) already imports the `nixosModule`. The `agenix` CLI is available in the dev shell as well.

You can fetch the host public key either from the host live, or by referring to your own `known_hosts` file with either `ssh-keygen -F <target>` or `ssh-keyscan`. For the latter, you can also query specifically for the shorter Ed25519 key with `ssh-keyscan -t ed25519`.

You can generate the secret token with e.g. `openssl rand -hex 32`, and wire it in using the `services.k3s.tokenFile` option.

**Note:** Changing the bootstrapping token after a cluster has already been formed will lead to the nodes failing to start; you'll have to remove the K3s data directory at `/var/lib/rancher/k3s`; this will remove **all** cluster data.

#### Extra

It is possible to use a YubiKey as the identity for `agenix` / `age` using [`age-plugin-yubikey`](https://github.com/str4d/age-plugin-yubikey) for the identity.

### Managing Kubernetes objects with Nixidy and Flux

At this point we have a Kubernetes cluster formed by NixOS hosts running K3s, but we aren't running anything in that cluster. While it's of course possible to start manually installing apps, let's keep the GitOps flowing using [Nixidy](https://nixidy.dev/) and [Flux](https://fluxcd.io/)!

Now, this selection requires some background for each:

1. We use Flux for its controller-oriented, declarative workflow; Argo CD is also an option, but we don't want any web UIs for a purely GitOps deployment.
2. We use Nixidy instead of e.g. [kubenix](https://kubenix.org/) for its typed CRD import support.

Nixidy's generated environment includes an Argo CD-oriented application output, but its rendered manifests can also be packaged for Flux. The adapter in [`flake-modules/kubernetes.nix`](flake-modules/kubernetes.nix) excludes that application output and builds an _OCI artifact_ from the remaining manifests. We use Nixidy to define Kubernetes objects, publish the rendered manifests as an OCI artifact, and use Flux to apply that artifact to the cluster.

#### Tasks

There are three parts you need to implement here:

1. Use Nixidy to define Kubernetes objects
2. Configure an OCI registry for storing the artifacts
3. Deploy Flux to apply the artifact from the registry

##### Nixidy

The [`flake-modules/kubernetes.nix`](flake-modules/kubernetes.nix) module uses [`kubernetes/environments/workshop.nix`](kubernetes/environments/workshop.nix) as its entrypoint, waiting for you to add your own deployments. A Nixidy "application" might look something like this:

```nix
{
  applications.hello = {
    # Deploy the application in the `hello` namespace.
    namespace = "hello";
    createNamespace = true;

    # The objects we want to include go here.
    resources = {
      # We define a Deployment object named `hello`.
      deployments.hello.spec = {
        replicas = 1;
        selector.matchLabels.app = "hello";
        # The Deployment defines a Pod template.
        template = {
          metadata.labels.app = "hello";
          # The Pod contains a single `hello` container.
          spec.containers.hello = {
            image = "nginx:1.27-alpine";
            ports.http.containerPort = 80;
          };
        };
      };

      # We also define a Service to route traffic to our Pods.
      services.hello.spec = {
        selector.app = "hello";
        ports.http.port = 80;
      };
    };
  };
}
```

You can build the manifests with `nix build .#artifact`, which should produce something like this:

```
result
├── hello
│   ├── Deployment-hello.yaml
│   ├── Namespace-hello.yaml
│   └── Service-hello.yaml
└── kustomization.yaml
```

The `kustomization.yaml` file is used by the [Kustomize](https://kubectl.docs.kubernetes.io/guides/introduction/kustomize/) system, which is both integrated into `kubectl` for manual use, and is the primary method for Flux to apply Kubernetes objects. In this case, it'll point to all the other files in the result.

If you wish, you can copy this directory onto one of the nodes via e.g. `scp`, then use `kubectl apply -k result`, then verify:

```
[root@magpie:~]# kubectl apply -k result
namespace/hello created
service/hello created
deployment.apps/hello created

[root@magpie:~]# kubectl get pods --namespace hello
NAME                     READY   STATUS    RESTARTS   AGE
hello-6f5dc6d498-w244d   1/1     Running   0          8s
```

Quite often you'll be deploying existing applications, and the most common method in the Kubernetes ecosystem is to do so using [Helm](https://helm.sh/); in short, Helm is used to template YAML files given some input values. Nixidy has [first-class Helm support](https://nixidy.dev/user_guide/helm_charts/), allowing patching the Helm-rendered output as well. Some applications define their own Kubernetes objects using CustomResourceDefinition objects (CRDs), and Nixidy supports parsing these to produce properly typed Nix options as well, both manually and [from Helm charts](https://nixidy.dev/user_guide/typed_resources/#from-helm-chart-crds-fromchartcrd).

##### OCI Registry

For the purposes of this workshop, we can deploy a simple OCI registry on one of the cluster nodes; this avoids having to tackle _Kubernetes_ secret management for authentication. The minimal configuration is merely to configure `services.dockerRegistry` to run on one of the NixOS hosts.

Assuming you deployed the registry on the host using the `server-init` role, `nix run .#publish` builds the OCI artifact, opens an SSH tunnel to that host, and pushes the artifact as `nix-cluster:latest`. If your registry is elsewhere, adjust [`flake-modules/kubernetes.nix`](flake-modules/kubernetes.nix) and [`kubernetes/modules/flux.nix`](kubernetes/modules/flux.nix) together.

##### Flux

While it's possible to install Flux manually using the `flux` CLI (which is also the official method), there are benefits to having Flux apply itself; that is, define the Flux installation via Nixidy. While we don't have Flux to apply the artifact yet, we can apply it manually _once_, and then Flux will take over.

Flux is released as a manifest archive on their [GitHub](https://github.com/fluxcd/flux2/releases); we can use `pkgs.fetchzip` to fetch it, then parse the manifests into Nixidy. We'll also use the [`fromCRDModule`](https://nixidy.dev/user_guide/typed_resources/#as-a-module-value-fromcrdmodule-fromchartcrdmodule) method to import the CustomResourceDefinition resources, and [`lib.kube.fromYAML`](https://nixidy.dev/library/#libkubefromyaml) to handle the rest:

```nix
{
  pkgs,
  generators,
  ...
}:
let
  version = "2.9.5";
  src = pkgs.fetchzip {
    url = "https://github.com/fluxcd/flux2/releases/download/v${version}/manifests.tar.gz";
    hash = "sha256-pYz+UNYnBYSIFdWbK9bcckJhgCMGm8EZDC/DXtXNwDE=";
    stripRoot = false;
  };
in
{
  # Import the CRDs from the given files as Nixidy options.
  nixidy.applicationImports = [
    (generators.fromCRDModule {
      inherit src;
      name = "flux";
      crdFiles = [
        "source-controller.yaml"
        "kustomize-controller.yaml"
        "notification-controller.yaml"
      ];
    })
  ];

  # The Flux deployment itself.
  applications.flux = {
    namespace = "flux-system";
    createNamespace = true;

    # Nixidy can parse YAML files into objects like this.
    yamls = map (file: builtins.readFile "${src}/${file}") [
      "helm-controller.yaml"
      "image-automation-controller.yaml"
      "image-reflector-controller.yaml"
      "kustomize-controller.yaml"
      "notification-controller.yaml"
      "policies.yaml"
      "rbac.yaml"
      "source-controller.yaml"
      "source-watcher.yaml"
    ];
  };
}
```

This handles the Flux installation itself, and you may apply this to the cluster if you wish.

Now, to tell Flux to apply manifests from our registry, we'll use the Flux CRDs: a [Source Controller](https://fluxcd.io/flux/components/source/) (specifically an [OCIRepository](https://fluxcd.io/flux/components/source/ocirepositories/)) that'll fetch the OCI artifact, then a [Kustomize Controller](https://fluxcd.io/flux/components/kustomize/) to apply it.

The sample OCIRepository looks like this in YAML:

```YAML
apiVersion: source.toolkit.fluxcd.io/v1
kind: OCIRepository
metadata:
  name: podinfo
spec:
  interval: 5m0s
  url: oci://ghcr.io/stefanprodan/manifests/podinfo
  ref:
    tag: latest
```

While we could import the YAML file directly, we can now use the typed Nixidy options, as we imported the CRDs, like this:

```nix
resources = {
  ociRepositories = {
    podinfo.spec = {
      interval = "5m0s";
      url = "oci://ghcr.io/stefanprodan/manifests/podinfo";
      ref = {
        tag = "latest";
      };
    };
  };
};
```

Check the [OCIRepository](https://fluxcd.io/flux/components/source/ocirepositories/) and [Kustomization](https://fluxcd.io/flux/components/kustomize/kustomizations/) documentation, and write both an appropriate OCIRepository pointing to the registry host and a Kustomization that takes that source and applies it to the cluster.

After all that is done, you should be able to build the artifact and apply it manually (remember to publish before applying):

```
nix run .#publish
nix build .#artifact
scp -P <port> -r result root@<host>:
ssh -p <port> root@<host>

[root@magpie:~]# kubectl apply -k result/

[root@magpie:~]# kubectl get ocirepository --all-namespaces
NAMESPACE     NAME      URL                                   READY   STATUS                                                                                                        AGE
flux-system   cluster   oci://172.30.240.1:5000/nix-cluster   True    stored artifact for digest 'latest@sha256:ca6e924726dfe2dbb55437890eadb857b24e16997977f818be00cdb85ea6f1bf'   15m

[root@magpie:~]# kubectl get kustomization --all-namespaces
NAMESPACE     NAME      AGE   READY   STATUS
flux-system   cluster   15m   True    Applied revision: latest@sha256:ca6e924726dfe2dbb55437890eadb857b24e16997977f818be00cdb85ea6f1bf
```

You can also verify that Flux has taken ownership of its own components, by viewing the labels of any of the Flux Deployments:

```
[root@magpie:~]# kubectl describe -n flux-system deployments.apps kustomize-controller
Name:                   kustomize-controller
Namespace:              flux-system
CreationTimestamp:      Tue, 01 Sep 2026 15:25:10 +0000
Labels:                 app.kubernetes.io/component=kustomize-controller
                        app.kubernetes.io/part-of=flux
                        control-plane=controller
                        kustomize.toolkit.fluxcd.io/name=cluster
                        kustomize.toolkit.fluxcd.io/namespace=flux-system
```

The `kustomize.toolkit.fluxcd.io/name=cluster` label corresponds to the Kustomization object that controls this object.

You can now create new Nixidy applications and deploy them just by running `nix run .#publish`!

### Next steps

There are some deliberate shortcuts here and plenty of room for improvement. Possible follow-up topics include:

- **Harden the registry:** add TLS and authentication, provide Flux credentials through `secretRef`.
- **Protect the artifact supply chain:** publish immutable version tags or digests, reject dirty working trees, sign artifacts with Cosign or Notation, and configure Flux verification.
- **Tighten cluster networking:** scope the K3s API, etcd, and Flannel firewall rules to the cluster interface and only the nodes that need each port.
- **Remove duplicated topology data:** derive the K3s `serverAddr`, registry endpoint, and publishing target from the host inventory, and assert that exactly one `server-init` host exists.
- **Practice recovery and rotation:** take and restore embedded-etcd snapshots, back up the matching server token, and test the supported `k3s token rotate` workflow.
- **Use least-privilege deployment access:** replace direct root SSH with a dedicated deployment user and narrowly scoped `sudo` rules.
- **Improve reproducibility:** pin workload container images by digest and decide how K3s, Flux, and application upgrades should be tested and rolled back.
- **Add automated checks:** format and statically analyze Nix files, evaluate every host, build the Kubernetes artifact, validate its YAML/Kustomize output, and run these checks in CI.
- **Add observability:** collect cluster and Flux metrics, centralize logs, define alerts, and document how to diagnose failed source or Kustomization reconciliations.
