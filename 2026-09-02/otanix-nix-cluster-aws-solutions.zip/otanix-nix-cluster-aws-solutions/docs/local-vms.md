# Local VMs

If you wish to use QEMU VMs instead of remote hosts, you may make use of the package defined in [`flake-modules/vms.nix`](../flake-modules/vms.nix) and the NixOS module defined in [`hosts/modules/qemu.nix`](../hosts/modules/qemu.nix).

## Configuration

First, you'll need to configure the VMs in the [host inventory](../hosts/default.nix), defining the following fields for each:

- `targetHost`: The VM will be reachable at `localhost`
- `targetPort`: Each VM should have a separate port, as they share `targetHost`
- `clusterAddress`: This will be the IP address used by the VM in the internal network

The cluster MAC address is derived from the host name, so it remains stable without
additional inventory configuration. The other values are largely arbitrary; you can
use the values below, substituting `XX` with a numerical ID of your node:

```nix
targetHost = "localhost";
targetPort = 22XX;
clusterAddress = "172.30.240.0XX";
```

Also include the [`./modules/qemu`](../hosts/modules/qemu.nix) in the modules list.

## Operation

To run the VMs, just run `nix run .#vms`.

The VMs will store their state (disks) in `vm-state` in the repository root; if you wish to recreate the VMs due to e.g. misconfiguration, you can remove that directory and restart the VMs. Note that you will need to remove the machines from your `known_hosts` file if you've connected to them:

```sh
ssh-keygen -R [localhost]:22XX # Change the port accordingly
```

Afterwards, you can proceed with the rest of the workshop as if the VMs were remote hosts.
