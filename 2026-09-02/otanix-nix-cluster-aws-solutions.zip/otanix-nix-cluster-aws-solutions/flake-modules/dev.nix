{ inputs, ... }:
{
  perSystem =
    { pkgs, system, ... }:
    let
      agenix = inputs.agenix.packages.${system}.default;
      colmena = inputs.colmena.packages.${system}.colmena;
      nixidy = inputs.nixidy.packages.${system}.default;
    in
    {
      formatter = pkgs.nixfmt-tree;

      devShells.default = pkgs.mkShellNoCC {
        packages =
          with pkgs;
          [
            fluxcd
            kubectl
            k9s
            kustomize
            openssl
          ]
          ++ [
            agenix
            colmena
            nixidy
          ];
      };
    };
}
