{ inputs, lib, ... }:
let
  hosts = import ../hosts;

  namedHosts = lib.mapAttrs (name: host: host // { inherit name; }) hosts;

  nixpkgsFor =
    host:
    import inputs.nixpkgs {
      system = host.system;
      config.allowUnfree = false;
    };

  hostModules =
    host:
    [
      inputs.agenix.nixosModules.default
      {
        _module.args = {
          inherit host;
          hosts = namedHosts;
        };
      }
    ]
    ++ host.modules;

  deployment = host: {
    targetHost = host.targetHost;
    targetPort = host.targetPort;
    targetUser = "root";
    tags = [ host.role ];
    buildOnTarget = host.system != "x86_64-linux";
  };

  firstHost = lib.head (lib.attrValues namedHosts);

  hiveConfig = {
    meta = {
      nixpkgs = nixpkgsFor firstHost;
      nodeNixpkgs = lib.mapAttrs (_: nixpkgsFor) namedHosts;
    };
  }
  // lib.mapAttrs (_: host: {
    imports = hostModules host;
    deployment = deployment host;
  }) namedHosts;
in
{
  flake = {
    colmenaHive = inputs.colmena.lib.makeHive hiveConfig;

    nixosConfigurations = lib.mapAttrs (
      _: host:
      inputs.nixpkgs.lib.nixosSystem {
        system = host.system;
        modules = hostModules host;
      }
    ) namedHosts;
  };
}
