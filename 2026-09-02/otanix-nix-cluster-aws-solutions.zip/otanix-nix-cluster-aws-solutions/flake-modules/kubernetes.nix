{ inputs, lib, ... }:
{
  perSystem =
    { pkgs, system, ... }:
    let
      envs = inputs.nixidy.lib.mkEnvs {
        inherit pkgs;
        envs.workshop.modules = [ ../kubernetes/environments/workshop.nix ];
      };

      rendered = envs.workshop.config.build.environmentPackage;
      nixidy = inputs.nixidy.packages.${system}.default;

      hosts = import ../hosts;
      initialServerNames = lib.attrNames (lib.filterAttrs (_: host: host.role == "server-init") hosts);
      initialServerName = lib.head initialServerNames;
      initialServer = hosts.${initialServerName};

      artifact =
        pkgs.runCommand "kubernetes-workshop"
          {
            nativeBuildInputs = [ pkgs.findutils ];
          }
          ''
            mkdir -p $out

            while IFS= read -r source; do
              relative="''${source#${rendered}/}"
              case "$relative" in
                apps/*) continue ;;
              esac

              destination="$out/$relative"
              mkdir -p "$(dirname "$destination")"
              cp -L "$source" "$destination"
            done < <(find -L ${rendered} -type f -name '*.yaml' | sort)

            {
              echo 'apiVersion: kustomize.config.k8s.io/v1beta1'
              echo 'kind: Kustomization'
              echo 'resources:'
              find "$out" -type f -name '*.yaml' ! -name kustomization.yaml \
                -printf '  - ./%P\n' | sort
            } > $out/kustomization.yaml
          '';

      publish = pkgs.writeShellApplication {
        name = "publish-kubernetes";
        runtimeInputs =
          with pkgs;
          [
            coreutils
            fluxcd
            git
            openssh
          ]
          ++ [ nixidy ];
        text = ''
          repository="oci://127.0.0.1:5000/nix-cluster"

          work_dir="$(mktemp -d)"
          control_socket="$work_dir/control"
          artifact_dir="$work_dir/artifact"
          cp -R ${artifact} "$artifact_dir"
          chmod -R u+w "$artifact_dir"
          cleanup() {
            ssh -S "$control_socket" -O exit -p ${toString initialServer.targetPort} root@${initialServer.targetHost} 2>/dev/null || true
            rm -rf "$work_dir"
          }
          trap cleanup EXIT

          ssh \
            -M -S "$control_socket" \
            -fNT \
            -o ExitOnForwardFailure=yes \
            -p ${toString initialServer.targetPort} \
            -L 5000:${initialServer.clusterAddress}:5000 \
            root@${initialServer.targetHost}

          source_url="$(git config --get remote.origin.url 2>/dev/null || printf unknown)"
          revision="$(git rev-parse HEAD 2>/dev/null || printf dirty)"

          flux push artifact "$repository:latest" \
            --path="$artifact_dir" \
            --source="$source_url" \
            --revision="$revision" \
            --insecure-registry
        '';
      };
    in
    {
      _module.args.nixidyEnvs = envs;

      packages = {
        inherit nixidy artifact publish;
      };

      apps.publish = {
        type = "app";
        program = lib.getExe publish;
      };
    };
}
