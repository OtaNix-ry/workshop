{ inputs, lib, ... }:
let
  hosts = import ../hosts;
  qemuModule = ../hosts/modules/qemu.nix;

  vmNodes = lib.filterAttrs (
    _: host: host.system == "x86_64-linux" && builtins.elem qemuModule host.modules
  ) hosts;

  allHosts = lib.mapAttrs (name: host: host // { inherit name; }) hosts;

  vmSystems = lib.mapAttrs (
    name: host:
    inputs.nixpkgs.lib.nixosSystem {
      system = host.system;
      modules = [
        inputs.agenix.nixosModules.default
        {
          _module.args = {
            host = host // {
              inherit name;
            };
            hosts = allHosts;
          };
        }
      ]
      ++ host.modules;
    }
  ) vmNodes;

  vmRunner =
    pkgs:
    pkgs.writeShellApplication {
      name = "workshop-vms";
      runtimeInputs = with pkgs; [
        coreutils
        jq
        qemu
        vde2
      ];
      text = ''
        mkdir -p vm-state
        cd vm-state

        # VDE uses fixed-size buffers for socket paths, so keep its transient
        # socket outside potentially long repository/worktree paths.
        VDE_RUNTIME_DIR="$(mktemp -d -t workshop-vms.XXXXXX)"
        cleanup() {
          rm -rf "$VDE_RUNTIME_DIR"
          kill 0 2>/dev/null || true
        }
        trap cleanup EXIT INT TERM

        VDE_CLUSTER_SOCKET="$VDE_RUNTIME_DIR/cluster.vde"
        export VDE_CLUSTER_SOCKET
        rm -rf "$VDE_CLUSTER_SOCKET"
        vde_switch --sock "$VDE_CLUSTER_SOCKET" --nostdin >cluster-switch.log 2>&1 &

        for _ in $(seq 1 50); do
          if [ -S "$VDE_CLUSTER_SOCKET/ctl" ]; then
            break
          fi
          sleep 0.1
        done
        if [ ! -S "$VDE_CLUSTER_SOCKET/ctl" ]; then
          echo "The local cluster network switch failed to start; see vm-state/cluster-switch.log." >&2
          exit 1
        fi

        ${lib.concatStringsSep "\n" (
          lib.mapAttrsToList (name: vm: ''
            ${vm.config.system.build.vmWithBootLoader}/bin/run-${name}-vm >${name}.log 2>&1 &
          '') vmSystems
        )}

        echo "Bootstrap VMs are starting:"
        ${lib.concatStringsSep "\n" (
          lib.mapAttrsToList (name: node: ''
            echo "  ${name}: ssh -p ${toString node.targetPort} root@localhost"
          '') vmNodes
        )}
        echo "Logs and mutable disks are in vm-state/. Press Ctrl-C to stop."
        wait
      '';
    };
in
{
  perSystem =
    { pkgs, system, ... }:
    lib.mkIf (system == "x86_64-linux") {
      packages.vms = vmRunner pkgs;

      apps.vms = {
        type = "app";
        program = lib.getExe (vmRunner pkgs);
      };
    };

  flake.nixosConfigurations = lib.mapAttrs' (
    name: value: lib.nameValuePair "bootstrap-${name}" value
  ) vmSystems;
}
