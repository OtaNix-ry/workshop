{
  description = "Kubernetes Meets NixOS";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

    # flake-parts allows us to structure our flake more cleanly.
    flake-parts.url = "github:hercules-ci/flake-parts";
    flake-parts.inputs.nixpkgs-lib.follows = "nixpkgs";

    # NixOS deployment tool.
    colmena.url = "github:zhaofengli/colmena";
    colmena.inputs.nixpkgs.follows = "nixpkgs";

    # Secrets management using age.
    agenix.url = "github:ryantm/agenix";
    agenix.inputs.nixpkgs.follows = "nixpkgs";

    # Kubernetes interfaces for Nix.
    nixidy.url = "github:arnarg/nixidy/latest";
    nixidy.inputs.nixpkgs.follows = "nixpkgs";
  };

  outputs =
    inputs@{ flake-parts, ... }:
    flake-parts.lib.mkFlake { inherit inputs; } {
      imports = [
        ./flake-modules/dev.nix
        ./flake-modules/hosts.nix
        ./flake-modules/kubernetes.nix
        ./flake-modules/vms.nix # Optionally you can use local VMs in place of remote hosts.
      ];
      systems = [ "x86_64-linux" ];
    };
}
