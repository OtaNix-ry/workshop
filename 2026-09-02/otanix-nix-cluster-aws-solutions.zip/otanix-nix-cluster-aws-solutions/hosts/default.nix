{
  # For new machines, set stateVersion to the NixOS release provided by the current nixpkgs input.
  magpie = {
    system = "x86_64-linux";
    stateVersion = "26.11";
    targetHost = "ec2-16-16-100-153.eu-north-1.compute.amazonaws.com";
    targetPort = 22;
    role = "server-init"; # This is our bootstrapping host

    clusterAddress = "172.31.2.154";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      ./modules/aws.nix
      ./modules/k3s.nix
      ./modules/registry.nix
    ];
  };

  crow = {
    system = "x86_64-linux";
    stateVersion = "26.11";
    targetHost = "ec2-16-192-186-176.eu-north-1.compute.amazonaws.com";
    targetPort = 22;
    role = "server";

    clusterAddress = "172.31.9.7";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      ./modules/aws.nix
      ./modules/k3s.nix
    ];
  };

  raven = {
    system = "x86_64-linux";
    stateVersion = "26.11";
    targetHost = "ec2-16-192-198-49.eu-north-1.compute.amazonaws.com";
    targetPort = 22;
    role = "server";

    clusterAddress = "172.31.5.38";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      ./modules/aws.nix
      ./modules/k3s.nix
    ];
  };
}
