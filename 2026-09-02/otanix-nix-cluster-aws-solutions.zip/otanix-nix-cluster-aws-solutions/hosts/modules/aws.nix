{ modulesPath, ... }:
{
  imports = [ "${modulesPath}/virtualisation/amazon-image.nix" ];

  boot.loader = {
    grub = {
      enable = true;
      device = "/dev/xvda";
      efiSupport = false;
    };
    systemd-boot.enable = false;
  };
}
