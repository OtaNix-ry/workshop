{ host, pkgs, ... }:
{
  networking = {
    hostName = host.name;
    firewall.enable = true;
  };

  nix.settings.experimental-features = [
    "nix-command"
    "flakes"
  ];

  # You can put any tools you might want here.
  environment.systemPackages = with pkgs; [
    nano
    fastfetch
  ];

  system.stateVersion = host.stateVersion;
}
