{ ... }:
{
  # Allow these public keys to SSH in as root; this is our management access.
  users.users.root.openssh.authorizedKeys.keys = [
    "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBxfJTK4xKS4cJPxX/kWgnnsF8TQAempdMo09xaJACDE polychoronix@hexadecachoron"
  ];

  services.openssh = {
    enable = true; # Enable the OpenSSH server.
    settings = {
      # We only use SSH, no passwords.
      PasswordAuthentication = false;
      PermitRootLogin = "prohibit-password";
    };
  };
}
