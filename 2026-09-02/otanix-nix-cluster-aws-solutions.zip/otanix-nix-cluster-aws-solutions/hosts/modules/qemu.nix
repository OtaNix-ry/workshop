{
  host,
  lib,
  modulesPath,
  ...
}:
let
  hostHash = builtins.hashString "sha256" host.name;
  clusterMacAddress = lib.concatStringsSep ":" (
    [ "02" ]
    ++ map (offset: builtins.substring offset 2 hostHash) [
      0
      2
      4
      6
      8
    ]
  );
  clusterLink = {
    matchConfig.MACAddress = clusterMacAddress;
    linkConfig.Name = "cluster0";
  };
in
{
  imports = [ "${modulesPath}/profiles/qemu-guest.nix" ];

  networking.interfaces.cluster0 = {
    useDHCP = lib.mkForce false;
    ipv4.addresses = lib.mkForce [
      {
        address = host.clusterAddress;
        prefixLength = 24;
      }
    ];
  };

  # The NIC is first seen and named in stage 1. Install the link rule in both
  # stages so scripted networking can configure it as cluster0 in stage 2.
  boot.initrd.systemd.network.links."10-cluster" = clusterLink;
  systemd.network.links."10-cluster" = clusterLink;

  virtualisation.vmVariantWithBootLoader = {
    # The backing image is sized to its initial contents. Grow its root
    # partition and filesystem to fill the larger persistent overlay.
    boot.growPartition = true;
    virtualisation = {
      memorySize = 2048;
      cores = 2;
      diskSize = 16 * 1024;
      graphics = false;
      fileSystems."/".autoResize = true;

      forwardPorts = [
        {
          from = "host";
          host.port = host.targetPort;
          guest.port = 22;
        }
      ];

      qemu.options = [
        "-netdev vde,id=cluster,sock=\${VDE_CLUSTER_SOCKET}"
        "-device virtio-net-pci,netdev=cluster,mac=${clusterMacAddress}"
      ];
    };
  };

  # The local VM launcher exposes its persistent boot disk with serial "root".
  boot.loader.grub.device = lib.mkDefault "/dev/disk/by-id/virtio-root";

  fileSystems."/" = lib.mkDefault {
    device = "/dev/disk/by-label/nixos";
    fsType = "ext4";
  };
}
