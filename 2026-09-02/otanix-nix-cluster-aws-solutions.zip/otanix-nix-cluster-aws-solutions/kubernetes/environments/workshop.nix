{
  imports = [ ../modules/flux.nix ];

  # Nixidy currently models an Argo-oriented target. Its generated app-of-apps
  # output is deliberately excluded from the Flux OCI package.
  nixidy.target = {
    repository = "https://example.invalid/nix-cluster.git";
    branch = "main";
    rootPath = "./manifests/workshop";
  };
}
