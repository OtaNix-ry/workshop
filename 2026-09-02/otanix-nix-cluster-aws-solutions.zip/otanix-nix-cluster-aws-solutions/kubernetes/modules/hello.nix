{
  applications.hello = {
    # Deploy the application in the `hello` namespace.
    namespace = "hello";
    createNamespace = true;

    # The objects we want to include go here.
    resources = {
      # We define a Deployment object named `hello`.
      deployments.hello.spec = {
        replicas = 1;
        selector.matchLabels.app = "hello";
        # The Deployment defines a Pod template.
        template = {
          metadata.labels.app = "hello";
          # The Pod contains a single `hello` container.
          spec.containers.hello = {
            image = "nginx:1.27-alpine";
            ports.http.containerPort = 80;
          };
        };
      };

      # We also define a Service to route traffic to our Pods.
      services.hello.spec = {
        selector.app = "hello";
        ports.http.port = 80;
      };
    };
  };
}
