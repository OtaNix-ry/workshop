let
  deploy = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBxfJTK4xKS4cJPxX/kWgnnsF8TQAempdMo09xaJACDE polychoronix@hexadecachoron";

  magpie = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFmxMzGvT9GKuMDk6b3w4GlnrGd0LJGrYwc9S272aunm";
  crow = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAINHtkj+7eQF1uudOeNJONgf/0O0+PIU7P+pdg3vfxXte";
  raven = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJ9OY6+9x+Jvhrka+94VlVYCdw3lff4gUafOjUGVEjZ4";
  systems = [
    magpie
    crow
    raven
  ];
in
{
  "k3s.age".publicKeys = [ deploy ] ++ systems;
}
