{
  # For new machines, set stateVersion to the NixOS release provided by the current nixpkgs input.
  magpie = {
    system = "x86_64-linux";
    stateVersion = "26.11";
    targetHost = "localhost";
    targetPort = 2201;
    role = "server-init"; # This is our bootstrapping host

    clusterAddress = "172.30.240.1";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      ./modules/qemu.nix
      ./modules/k3s.nix
      ./modules/registry.nix
    ];
  };

  crow = {
    system = "x86_64-linux";
    stateVersion = "26.11";
    targetHost = "localhost";
    targetPort = 2202;
    role = "server";

    clusterAddress = "172.30.240.2";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      ./modules/qemu.nix
      ./modules/k3s.nix
    ];
  };

  raven = {
    system = "x86_64-linux";
    stateVersion = "26.11";
    targetHost = "localhost";
    targetPort = 2203;
    role = "server";

    clusterAddress = "172.30.240.3";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      ./modules/qemu.nix
      ./modules/k3s.nix
    ];
  };
}
