{ host, lib, config, ... }:
let
  isServer = host.role != "agent";
in
{
  age.secrets.k3s.file = ../../secrets/k3s.age;

  networking.firewall.allowedTCPPorts = [
    6443 # k3s: required so that pods can reach the API server (running on port 6443 by default)
    2379 # k3s, etcd clients: required if using a "High Availability Embedded etcd" configuration
    2380 # k3s, etcd peers: required if using a "High Availability Embedded etcd" configuration
  ];
  networking.firewall.allowedUDPPorts = [
    8472 # k3s, flannel: required if using multi-node for inter-node networking
  ];

  services.k3s = {
    enable = true;
    role = if isServer then "server" else "agent";
    clusterInit = lib.mkIf (host.role == "server-init") true;
    serverAddr = lib.mkIf (host.role != "server-init") "https://172.30.240.1:6443";
    tokenFile = config.age.secrets.k3s.path;
    extraFlags = [
      "--flannel-iface=cluster0"
      "--node-ip=${host.clusterAddress}"
    ];
  };
}
