{
  pkgs,
  generators,
  ...
}:
let
  version = "2.9.5";
  src = pkgs.fetchzip {
    url = "https://github.com/fluxcd/flux2/releases/download/v${version}/manifests.tar.gz";
    hash = "sha256-pYz+UNYnBYSIFdWbK9bcckJhgCMGm8EZDC/DXtXNwDE=";
    stripRoot = false;
  };
in
{
  nixidy.applicationImports = [
    (generators.fromCRDModule {
      inherit src;
      name = "flux";
      crdFiles = [
        "source-controller.yaml"
        "kustomize-controller.yaml"
        "notification-controller.yaml"
      ];
    })
  ];

  applications.flux = {
    namespace = "flux-system";
    createNamespace = true;

    yamls = map (file: builtins.readFile "${src}/${file}") [
      "helm-controller.yaml"
      "image-automation-controller.yaml"
      "image-reflector-controller.yaml"
      "kustomize-controller.yaml"
      "notification-controller.yaml"
      "policies.yaml"
      "rbac.yaml"
      "source-controller.yaml"
      "source-watcher.yaml"
    ];

    resources = {
      ociRepositories = {
        cluster.spec = {
          interval = "1m0s";
          url = "oci://172.30.240.1:5000/nix-cluster";
          insecure = true;
          ref = {
            tag = "latest";
          };
        };
      };
      kustomizations = {
        cluster.spec = {
          interval = "1m0s";
          sourceRef = {
            kind = "OCIRepository";
            name = "cluster";
          };
          prune = true;
        };
      };
    };
  };
}
