let
  deploy = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBxfJTK4xKS4cJPxX/kWgnnsF8TQAempdMo09xaJACDE polychoronix@hexadecachoron";

  magpie = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK6EsIkY1nl3jhannT+g7ca+1tYUzBkA7GydOd1zd0os";
  crow = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOZGtx40Zr3N8En2laDtfxdz62wg7OJdtcgWIMAgCaF0";
  raven = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEISs3XZ07lKe8pgoCd2/0wTZ8ISoCSG1Y1n27E/DOba";
  systems = [
    magpie
    crow
    raven
  ];
in
{
  "k3s.age".publicKeys = [ deploy ] ++ systems;
}
