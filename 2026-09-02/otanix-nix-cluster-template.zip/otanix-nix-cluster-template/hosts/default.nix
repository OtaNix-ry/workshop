{
  # For new machines, set stateVersion to the NixOS release provided by the current nixpkgs input.
  magpie = {
    system = "x86_64-linux";
    targetHost = ""; # FIXME
    targetPort = 22;
    stateVersion = "26.11";
    role = "server-init"; # This is our bootstrapping host

    clusterAddress = "172.30.240.1";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      # ./modules/qemu.nix
    ];
  };

  crow = {
    system = "x86_64-linux";
    targetHost = ""; # FIXME
    targetPort = 22;
    stateVersion = "26.11";
    role = "server";

    clusterAddress = "172.30.240.2";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      # ./modules/qemu.nix
    ];
  };

  raven = {
    system = "x86_64-linux";
    targetHost = ""; # FIXME
    targetPort = 22;
    stateVersion = "26.11";
    role = "server";

    clusterAddress = "172.30.240.3";

    modules = [
      ./modules/common.nix
      ./modules/deployment-access.nix
      # ./modules/qemu.nix
    ];
  };
}
