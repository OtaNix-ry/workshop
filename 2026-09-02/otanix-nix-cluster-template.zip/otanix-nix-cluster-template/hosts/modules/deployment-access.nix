{ ... }:
{
  # Allow these public keys to SSH in as root; this is our management access.
  users.users.root.openssh.authorizedKeys.keys = [
    # FIXME: Add your key here
  ];

  services.openssh = {
    enable = true; # Enable the OpenSSH server.
    settings = {
      # We only use SSH, no passwords.
      PasswordAuthentication = false;
      PermitRootLogin = "prohibit-password";
    };
  };
}
